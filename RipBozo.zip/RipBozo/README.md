# RipBozo
WoW Addon to watch DeathLog for a specific character's demise.
